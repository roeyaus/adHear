//
//  platform.hpp
//  UIvWorker
//
//  Created by Roey L on 1/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef UIvWorker_platform_hpp
#define UIvWorker_platform_hpp

#define ZMQ_HAVE_OSX

#endif
