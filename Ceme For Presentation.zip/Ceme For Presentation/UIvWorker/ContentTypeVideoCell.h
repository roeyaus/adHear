//
//  ContentTypeVideoCell.h
//  UIvWorker
//
//  Created by Lion User on 20/05/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ContentTypeCellBase.h"

@interface ContentTypeVideoCell : UITableViewCell <ContentTypeCellBase>

- (int)getCellHeight;

@end
