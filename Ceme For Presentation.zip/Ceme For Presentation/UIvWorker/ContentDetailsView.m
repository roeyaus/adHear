//
//  Tab3.m
//  UIvWorker
//
//  Created by Igor Nakonetsnoi on 04/12/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ContentDetailsView.h"
#import "Screen5.h"
#import "ContentTypesAll.h"
#import "QuartzCore/CALayer.h"
#import "AllCells.h"
#import "FacebookManager.h"
#import "DataManager.h"
#import "User.h"
#import "VideosDetailView.h"
#import "FriendsDetailView.h"
#import "CouponDetailsViewController.h"

@implementation ContentDetailsView
@synthesize ivCouponImage;
@synthesize lblCouponDesc;
@synthesize tvcCouponCell;

@synthesize screenSwitched;

@synthesize tvContentDetails;
@synthesize tvcMainTitleCell;
@synthesize lblMainTitle;
@synthesize ivMainImage;
@synthesize lblMainDescription;
@synthesize btnBuyCoupon;
@synthesize ContentID;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        UIImage *img = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"icon-3" ofType: @"png"]];
       self.tabBarItem.image = img; 
     
    }
    ContentID = nil;
    return self;
}
							
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - Facebook Delegate methods

- (void)request:(FBRequest *)request didLoad:(id)result
{
    
}

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error
{
    
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (ContentID == nil)
    {
        ContentID = @"1";
    }
    contentArray = [[DataManager sharedSingleton] GetAllContentTypesByContentID:ContentID];
    
    usersWatchingArray = [[DataManager sharedSingleton] GetAllWatchingUserIdByContentId:ContentID];
    
    customCellsNib = [UINib nibWithNibName:@"ContentTypeCells" bundle:nil];
    //imgCoupon.clipsToBounds = NO;
    [self generateCellArray];
    
   
    
}


- (void)viewDidUnload
{

  
    [self setTvcMainTitleCell:nil];
    [self setLblMainTitle:nil];
    [self setIvMainImage:nil];
    [self setLblMainDescription:nil];
    [self setTvContentDetails:nil];

    [self setBtnBuyCoupon:nil];
    [self setIvCouponImage:nil];
    [self setLblCouponDesc:nil];
    [self setTvcCouponCell:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //change nav bar to blue
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:23/255.0 green:13/255.0 blue:176/255.0 alpha:1.0];
 
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
   
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
    
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
     
        

}


-(void)displayCouponDetails:(ContentTypeCoupon*) coup
{
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations. Currently portrait and upside down portrait supported.
    if ((interfaceOrientation == UIInterfaceOrientationPortrait) ||
        (interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown))
        return YES;
    
    return NO;
}

- (IBAction)BackButton:(id)sender {
    [self.tabBarController setSelectedIndex:0];
    
}

- (IBAction)OpenScreen5:(id)sender {
    Screen5 *screen5 = [[Screen5 alloc]
                        initWithNibName:@"Screen5" bundle:nil];
    screen5.hidesBottomBarWhenPushed = YES;
    screen5.parent = self;
    [self presentModalViewController:screen5 animated:YES];
  
}





- (void) updateCountdown {
    // this method updates the label with the timer.
    int hours, minutes, seconds;
    hours = secondsLeft / 3600;
    minutes = (secondsLeft % 3600) / 60;
    seconds = (secondsLeft %3600) % 60;
    secondsLeft -= 1;

}

//create cells for content types

- (void)generateCellArray
{
    cellsArray = [[NSMutableArray alloc] init];
    UITableViewCell* cell;
    
    for (int i = 0; i< contentArray.count ; ++i)
    {
        if ([[contentArray objectAtIndex:i] isKindOfClass:[ContentTypeGeneral class]])
        {
        
            cell = [self generateCellForContentTypeGeneral:(ContentTypeGeneral<IContentType>*)[ContentTypeGeneral GenerateByID:ContentID]];
            
            self.navigationItem.title = ((ContentTypeGeneral*)[contentArray objectAtIndex:i]).Title;
            
        }
        if ([[contentArray objectAtIndex:i] isKindOfClass:[ContentTypeCoupon class]])
        {
            cell = [self generateCellForContentTypeCoupon:(ContentTypeCoupon<IContentType>*)[ContentTypeCoupon GenerateByID:ContentID]];
            
        }
        if ([[contentArray objectAtIndex:i] isKindOfClass:[ContentTypeFriend class]])
        {
            cell = [self generateCellForContentTypeFriends:(ContentTypeFriend<IContentType>*)[ContentTypeFriend GenerateByID:ContentID]];
        
        } 
        if ([[contentArray objectAtIndex:i] isKindOfClass:[ContentTypeVideo class]])
        {
            cell = [self generateCellForContentTypeVideo];
        
        } 
        if ([[contentArray objectAtIndex:i] isKindOfClass:[ContentTypeRecipe class]])
        {
            cell = [self generateCellForContentTypeRecipe];
            
        } 
    
    
        UIView *backView = [[UIView alloc] initWithFrame:CGRectZero];
        backView.backgroundColor = [UIColor clearColor];
        cell.backgroundView = backView;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cellsArray addObject:cell];
    }
}


- (UITableViewCell*) generateCellForContentTypeGeneral:(ContentTypeGeneral <IContentType>*)general
{
    
    UITableViewCell *cell = [tvContentDetails dequeueReusableCellWithIdentifier:[ContentTypeGeneral GetCellIdentifier]];
    if(cell == nil) {
        NSArray *topLevelItems = [customCellsNib instantiateWithOwner:nil options:nil];
        NSUInteger idx = [topLevelItems indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop)
                          {
                              UITableViewCell *cell = (UITableViewCell *)obj;
                              return [cell isKindOfClass:[UITableViewCell class]] && [cell.reuseIdentifier isEqualToString:[ContentTypeGeneral GetCellIdentifier]];
                          } ];
        assert(idx != NSNotFound);
        cell = [topLevelItems objectAtIndex:idx];
    }
    
    UILabel* lblTitle = (UILabel*)[cell viewWithTag:1];
    //lbl1 = [[UILabel alloc] init];
    lblTitle.text = general.Title;
    UIImageView* img = (UIImageView*)[cell viewWithTag:2];
    img.image = general.Picture;
    UILabel* lblDescription = (UILabel*)[cell viewWithTag:3];
    //lbl2 = [[UILabel alloc] init];
    lblDescription.text = general.Description;
    UILabel* lblcast = (UILabel*)[cell viewWithTag:4];
    lblcast.text = general.Cast;
    return cell;
}

- (UITableViewCell*) generateCellForContentTypeCoupon:(ContentTypeCoupon<IContentType>*)coupon
{
    UITableViewCell *cell = [tvContentDetails dequeueReusableCellWithIdentifier:[ContentTypeCoupon GetCellIdentifier]];
    if(cell == nil) {
        NSArray *topLevelItems = [customCellsNib instantiateWithOwner:nil options:nil];
        NSUInteger idx = [topLevelItems indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop)
                          {
                              UITableViewCell *cell = (UITableViewCell *)obj;
                              return [cell isKindOfClass:[UITableViewCell class]] && [cell.reuseIdentifier isEqualToString:[ContentTypeCoupon GetCellIdentifier]];
                          } ];
        assert(idx != NSNotFound);
        cell = [topLevelItems objectAtIndex:idx];
    }
    
    UILabel* lblTitle = (UILabel*)[cell viewWithTag:2];
    //lbl1 = [[UILabel alloc] init];
    lblTitle.text = coupon.Description;
    UIImageView* img = (UIImageView*)[cell viewWithTag:1];
    img.image = coupon.Picture;
    
    lblTitle.font = [UIFont fontWithName:@"STHeitiSC-Light" size:15];
   
    
    return cell;
   
}

- (UITableViewCell*) generateCellForContentTypeFriends:(ContentTypeFriend<IContentType>*)friends
{
    UITableViewCell *cell = [tvContentDetails dequeueReusableCellWithIdentifier:[ContentTypeFriend GetCellIdentifier]];
    if(cell == nil) {
        NSArray *topLevelItems = [customCellsNib instantiateWithOwner:nil options:nil];
        NSUInteger idx = [topLevelItems indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop)
                          {
                              UITableViewCell *cell = (UITableViewCell *)obj;
                              return [cell isKindOfClass:[UITableViewCell class]] && [cell.reuseIdentifier isEqualToString:[ContentTypeFriend GetCellIdentifier]];
                          } ];
        assert(idx != NSNotFound);
        cell = [topLevelItems objectAtIndex:idx];
        
        int xCoordinate = 30;
        int yCoordinate = 35;
        
        for (int i = 0; i< usersWatchingArray.count; i++)
        {
            User* u = [usersWatchingArray objectAtIndex:i];
            CGRect ivrect = CGRectMake(xCoordinate, yCoordinate, 40, 40);
            CGRect lblrect = CGRectMake(xCoordinate, yCoordinate + 40, 40, 10);

            UILabel* lbl = [[UILabel alloc] initWithFrame:lblrect];
            UIImageView* iv = [[UIImageView alloc] initWithFrame:ivrect];
            iv.image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"DefaultFacebookProfile" ofType: @"jpg"]];
            [lbl setBackgroundColor:[UIColor clearColor]];
            lbl.textAlignment = UITextAlignmentCenter;
            lbl.font = [UIFont fontWithName:@"STHeitiSC-Light" size:9];
            lbl.textColor = [UIColor whiteColor];
            lbl.numberOfLines = 2;
            lbl.text = u.FullName;
            lbl.lineBreakMode = UILineBreakModeWordWrap;
            
            iv.tag = 10 + i;
            [cell addSubview:iv];
            [cell addSubview:lbl];
            xCoordinate += 47;
        }
    }
    
    UILabel* lblTitle = (UILabel*)[cell viewWithTag:1];

    //lbl1 = [[UILabel alloc] init];
    lblTitle.text = [NSString stringWithFormat:@"%d מחבריך צופים כרגע ", usersWatchingArray.count ];
   
    
    [self performSelectorInBackground:@selector(LoadUsersWatchingImagesAsync:) withObject:cell];
    
    return cell;
}

- (UITableViewCell*) generateCellForContentTypeVideo;
{
    
    UITableViewCell *cell = [tvContentDetails dequeueReusableCellWithIdentifier:[ContentTypeVideo GetCellIdentifier]];
    if(cell == nil) {
        NSArray *topLevelItems = [customCellsNib instantiateWithOwner:nil options:nil];
        NSUInteger idx = [topLevelItems indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop)
                          {
                              UITableViewCell *cell = (UITableViewCell *)obj;
                              return [cell isKindOfClass:[UITableViewCell class]] && [cell.reuseIdentifier isEqualToString:[ContentTypeVideo GetCellIdentifier]];
                          } ];
        assert(idx != NSNotFound);
        cell = [topLevelItems objectAtIndex:idx];
    }
    
    //query the datamanager for number of videos.
    
    NSMutableArray* aVideos =  [[DataManager sharedSingleton] GetVideosByContentId:@"1"];
    
    UILabel* lblTitle = (UILabel*)[cell viewWithTag:1];
    //lbl1 = [[UILabel alloc] init];
    lblTitle.text = [NSString stringWithFormat:@"ישנם %d קליפים הקשורים לתוכן     ", aVideos.count];
    UIImageView* img = (UIImageView*)[cell viewWithTag:2];
    img.image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"videoIcon-2" ofType: @"png"]];
    
    lblTitle.font = [UIFont fontWithName:@"STHeitiSC-Light" size:15];
    
    return cell;
}

- (UITableViewCell*) generateCellForContentTypeRecipe
{
    
    UITableViewCell *cell = [tvContentDetails dequeueReusableCellWithIdentifier:[ContentTypeRecipe GetCellIdentifier]];
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:[ContentTypeRecipe GetCellIdentifier]];
    }

    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = @"לחצו כאן למתכון מנצח!";
    cell.textLabel.font = [UIFont fontWithName:@"STHeitiSC-Light" size:17];
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.textAlignment = UITextAlignmentRight;
    cell.textLabel.shadowOffset = CGSizeMake(0, 0);
    cell.textLabel.shadowColor = [UIColor blackColor];
    
    cell.imageView.image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"recipeIcon" ofType: @"gif"]];
    
    return cell;
}


-(void)LoadUsersWatchingImagesAsync:(UITableViewCell*)cell
{
    
    for (int i = 0; i< usersWatchingArray.count; i++)
    {
        User* user = (User*)[usersWatchingArray objectAtIndex:i];
        
        UIImage* img = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:user.PictureURL]]];
        //labels begin from index 1
        UIImageView* iv = (UIImageView*)[cell viewWithTag:(10 + i)];
        //UIImageView* iv = (UIImageView*)[[(UILabel*)[[cell subviews] objectAtIndex:i+1] subviews] objectAtIndex:0];
        iv.image = img;
    }
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat ret = 0;
    
    ret = ((UITableViewCell*)[cellsArray objectAtIndex:indexPath.row]).frame.size.height;
    
    return ret;
    
}   

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    NSArray *topLevelItems = [customCellsNib instantiateWithOwner:nil options:nil];
    return contentArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int row = indexPath.row;
    return [cellsArray objectAtIndex:row];
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[contentArray objectAtIndex:indexPath.row] isKindOfClass:[ContentTypeCoupon class]])
    {
        CouponDetailsViewController *ContentDetailsView = [[CouponDetailsViewController alloc] initWithNibName:@"CouponDetailsViewController" bundle:nil];
        
      
        // ...
        // Pass the selected object to the new view controller.
        [self.navigationController pushViewController:ContentDetailsView animated:YES];
        ContentDetailsView.ivCouponDetails.image = ((ContentTypeCoupon*)[contentArray objectAtIndex:indexPath.row]).ActualCoupon; 
        
          }
    // Navigation logic may go here. Create and push another view controller.
    if ([[contentArray objectAtIndex:indexPath.row] isKindOfClass:[ContentTypeFriend class]])
    {
        FriendsDetailView *FriendsDetailsView = [[FriendsDetailView alloc] initWithNibName:@"FriendsDetailView" bundle:nil];
        // ...
        // Pass the selected object to the new view controller.
        [self.navigationController pushViewController:FriendsDetailsView animated:YES];
    }
    
    if ([[contentArray objectAtIndex:indexPath.row] isKindOfClass:[ContentTypeVideo class]])
    {
        VideosDetailView *videoDetailsView = [[VideosDetailView alloc] initWithNibName:@"VideosDetailView" bundle:nil];
        // ...
        // Pass the selected object to the new view controller.
        [self.navigationController pushViewController:videoDetailsView animated:YES];
    }
    
    
     
}



@end
