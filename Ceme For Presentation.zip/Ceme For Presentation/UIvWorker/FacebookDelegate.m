//
//  FacebookDelegate.m
//  UIvWorker
//
//  Created by user on 2/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FacebookDelegate.h"
#import "Facebook.h"
@implementation FacebookDelegate

- (void)fbDidLogin
{
    
}

@end
