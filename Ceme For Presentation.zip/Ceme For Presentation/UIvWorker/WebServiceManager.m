//
//  WebServiceManager.m
//  UIvWorker
//
//  Created by user on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "WebServiceManager.h"

@implementation WebServiceManager

-(NSMutableArray*)GetAllContentTypesByContentID:(NSString*)ContentID
{
    //run appropriate webservice method with contentID and get the response, then create an NSArray of objects with the returned content types for this contentID
}

@end
