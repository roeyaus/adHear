//
//  CouponDetailsViewController.h
//  UIvWorker
//
//  Created by Lion User on 13/05/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CouponDetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *ivCouponDetails;

@end
