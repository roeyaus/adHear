//
//  WebServiceManager.h
//  UIvWorker
//
//  Created by user on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebServiceManager : NSObject
{
    
}

-(NSMutableArray*)GetAllContentTypesByContentID:(NSString*)ContentID;


@end
