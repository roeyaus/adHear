//
//  ContentTypeVideoCell.m
//  UIvWorker
//
//  Created by Lion User on 20/05/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContentTypeVideoCell.h"

@implementation ContentTypeVideoCell

- (int)getCellHeight
{
    return 82;
}

@end
