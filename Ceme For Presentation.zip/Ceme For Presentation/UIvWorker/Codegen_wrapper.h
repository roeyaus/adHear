/*
 *  Codegen_wrapper.h
 *
 *  Created by Brian Whitman on 7/10/10.
 *  Copyright 2010 The Echo Nest. All rights reserved.
 *
 */

const char* codegen_wrapper(const float*pcm, int numSamples);