//
//  DataManager.m
//  UIvWorker
//
//  Created by user on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DataManager.h"
#import "ContentTypesAll.h"
#import "WebServiceManager.h"
#import "User.h"

@implementation DataManager


+ (DataManager *)sharedSingleton
{
    static DataManager *sharedSingleton;
    
    @synchronized(self)
    {
        if (!sharedSingleton)
            sharedSingleton = [[DataManager alloc] init];
        
        return sharedSingleton;
    }
}

//init webservice class
-(id)init
{
    if (self = [super init])
    {
        wsManager = [[WebServiceManager alloc] init];
    }
    return self;
}

//returns a dictionary where key: contentType enum and value = IContentType object
-(NSMutableArray*)GetAllContentTypesByContentID:(NSString*)ContentID
{
    NSMutableArray* contentArray = [[NSMutableArray alloc] init];
    //commercial #1
    if ([ContentID isEqualToString:@"1"])
    {
        [contentArray addObject:(id<IContentType>)[ContentTypeGeneral GenerateByID:ContentID]];
        [contentArray addObject:(id<IContentType>)[ContentTypeCoupon GenerateByID:ContentID]];
        [contentArray addObject:(id<IContentType>)[ContentTypeFriend GenerateByID:ContentID]];
        [contentArray addObject:(id<IContentType>)[ContentTypeVideo GenerateByID:ContentID]];
        
    }
    //commercial #2
    if ([ContentID isEqualToString:@"2"])
    {
        [contentArray addObject:(id<IContentType>)[ContentTypeGeneral GenerateByID:ContentID]];
        [contentArray addObject:(id<IContentType>)[ContentTypeCoupon GenerateByID:ContentID]];
        
        //no friends watching this commercial
        //[contentArray addObject:(id<IContentType>)[ContentTypeFriend GenerateByID:ContentID]];
        
        [contentArray addObject:(id<IContentType>)[ContentTypeVideo GenerateByID:ContentID]];
        
    }
    //show #3
    if ([ContentID isEqualToString:@"3"])
    {
        [contentArray addObject:(id<IContentType>)[ContentTypeGeneral GenerateByID:ContentID]];
        //[contentArray addObject:(id<IContentType>)[ContentTypeCoupon GenerateByID:ContentID]];
        
        
        [contentArray addObject:(id<IContentType>)[ContentTypeFriend GenerateByID:ContentID]];
        
        [contentArray addObject:(id<IContentType>)[ContentTypeVideo GenerateByID:ContentID]];
        
         [contentArray addObject:(id<IContentType>)[ContentTypeRecipe GenerateByID:ContentID]];
        
    }
    return contentArray;
    
}

-(NSMutableArray*)GetAllWatchingUserIdByContentId:(NSString*)ContentID
{
    NSMutableArray* aUsers = [[NSMutableArray alloc] init];
    
    //Temp code....till there's a webservice
    User* u1 = [[User alloc] init];
    u1.FacebookID = @"783084822";
    u1.FullName = @"Roey Lehman";
    u1.PictureURL = @"https://fbcdn-sphotos-a.akamaihd.net/hphotos-ak-ash4/230857_6905259822_783084822_283959_3552_n.jpg";
    u1.Picture = nil;
    
    [aUsers addObject:u1];
    User* u2 = [[User alloc] init];
    u2.FacebookID = @"783084822";
    u2.FullName = @"Yaron David";
    u2.PictureURL = @"https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc4/157806_1650845822_1396065775_n.jpg";
    u2.Picture = nil;
    
    [aUsers addObject:u2];
    User* u3 = [[User alloc] init];
    u3.FacebookID = @"783084822";
    u3.FullName = @"Amir Reiner";
    u3.PictureURL = @"https://fbcdn-sphotos-a.akamaihd.net/hphotos-ak-ash4/309459_250020265034281_100000789282632_605607_1229353424_n.jpg";
    u3.Picture = nil;
    
    [aUsers addObject:u3];
    User* u4 = [[User alloc] init];
    u4.FacebookID = @"783084822";
    u4.FullName = @"Tzach Nahmany";
    u4.PictureURL = @"https://fbcdn-sphotos-a.akamaihd.net/hphotos-ak-snc7/383721_10150430949070340_792590339_8471976_515094439_n.jpg";
    u4.Picture = nil;
    
    [aUsers addObject:u4];
    
    return aUsers;
}

-(NSMutableArray*)GetVideosByContentId:(NSString*)ContentID
{
    NSMutableArray* aVideos = [[NSMutableArray alloc] init];
    
    [aVideos addObject:[ContentTypeVideo GenerateByID:@"1"]];
    return aVideos;
    
}






@end
