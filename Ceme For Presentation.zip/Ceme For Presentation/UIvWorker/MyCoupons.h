//
//  MyCoupons.h
//  UIvWorker
//
//  Created by Roey L on 12/31/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCoupons : UITableViewController

@end
