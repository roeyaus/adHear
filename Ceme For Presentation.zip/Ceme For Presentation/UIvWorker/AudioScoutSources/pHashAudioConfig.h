// pHashAudio lib config settings
#define pHashAudio_VERSION_MAJOR 1
#define pHashAudio_VERSION_MINOR 0

#define HAVE_MPG123
