//
//  ContentTypeCellBase.h
//  UIvWorker
//
//  Created by Lion User on 12/05/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ContentTypeCellBase <NSObject>

- (int)getCellHeight;

@end
