//
//  ContentTypeVideos.m
//  UIvWorker
//
//  Created by user on 3/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContentTypeVideo.h"

@implementation ContentTypeVideo

@synthesize ID;
@synthesize Name;
@synthesize Description;
@synthesize URLToThumbnail;
@synthesize URL;


+(id<IContentType>) GenerateByID:(NSString*) Id
{
    ContentTypeVideo* ctv = [[ContentTypeVideo alloc] init];
    ctv.ID = 1;
    ctv.Name = @"כריות - הפרסומת";
    ctv.Description = @"הפרסומת של כריות מבית באומן בר-ריבנאי";
    ctv.URLToThumbnail = @"http://i2.ytimg.com/vi/aEGCH5sK2io/default.jpg";
    ctv.URL = @"http://www.youtube.com/watch?v=8i4wKT_k9WE";
    return ctv;
}

+(NSString*) GetCellIdentifier
{
    return @"VideoCell";
}

@end
